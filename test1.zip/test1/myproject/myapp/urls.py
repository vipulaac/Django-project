from django.contrib import admin
from django.urls import include, path

from myapp import views
urlpatterns = [
    path('',views.login),
    path('new/',views.new),
    path('home/<id>/',views.home),
    path('course/<id>/',views.course),
    path('teachers/<id>/',views.teachers),
    path('t_profile/<id>/',views.t_profile),
    path('contact/<id>/',views.contact),
    path('about/<id>/',views.about),
    path('t_playlist/<id>/',views.t_playlist),
    path('purchase/<id>/',views.purchase),
    path('update/<id>/',views.update)
]